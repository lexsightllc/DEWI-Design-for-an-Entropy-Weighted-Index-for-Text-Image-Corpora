""
DEWI: Design for an Entropy-Weighted Index for Text+Image Corpora

This module provides the command-line interface for DEWI.
"""

from dewi.cli import cli

if __name__ == "__main__":
    cli()
